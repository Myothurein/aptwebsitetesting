/* Aung Paing Tun Co., Ltd. (APT Pharma) — Interactive App Logic */

(function () {
      'use strict';

      const PRODUCTS = [
        { id: 'salbec-2g', name: 'SALBEC 2g', ingredient: 'Cefoperazone / Sulbactam', category: 'antibiotics', categoryLabel: 'Antibiotics & Injectables', pack: '1 vial + 10ml water for injection', maker: 'Medochemie (EU-GMP)', area: 'Hospital Antibiotic', summary: 'Injectable beta-lactam / beta-lactamase inhibitor for acute hospital care.' },
        { id: 'cilimeright', name: 'Cilimeright 500 mg / 500 mg', ingredient: 'Imipenem & Cilastatin USP', category: 'antibiotics', categoryLabel: 'Antibiotics & Injectables', pack: '500mg / 500mg IV Vial', maker: 'Alvita', area: 'Carbapenem Antibiotic', summary: 'Intravenous carbapenem antibiotic for severe inpatient infections.' },
        { id: 'meroright', name: 'Meroright 1g & 500mg', ingredient: 'Meropenem for Injection USP', category: 'antibiotics', categoryLabel: 'Antibiotics & Injectables', pack: '1g & 500mg IV Vials', maker: 'Alvita', area: 'Carbapenem Antibiotic', summary: 'Broad-spectrum intravenous meropenem for hospital antimicrobial therapy.' },
        { id: 'moxiclav', name: 'MOXICLAV 625mg & 375mg', ingredient: 'Amoxicillin / Clavulanic Acid', category: 'antibiotics', categoryLabel: 'Antibiotics & Injectables', pack: '15 Film-Coated Tablets', maker: 'Medochemie (EU-GMP)', area: 'Oral Antibiotic', summary: 'European-manufactured oral penicillin combination in dual strengths.' },
        { id: 'medolevo', name: 'MEDOLEVO 250mg & 500mg', ingredient: 'Levofloxacin', category: 'antibiotics', categoryLabel: 'Antibiotics & Injectables', pack: '10 Film-Coated Tablets', maker: 'Medochemie (EU-GMP)', area: 'Fluoroquinolone', summary: 'Dual-strength oral levofloxacin film-coated tablets.' },
        { id: 'mabron', name: 'MABRON 100mg/2ml', ingredient: 'Tramadol Hydrochloride', category: 'antibiotics', categoryLabel: 'Antibiotics & Injectables', pack: '10 x 2ml Ampoules', maker: 'Medochemie (EU-GMP)', area: 'Injectable Analgesic', summary: 'Sterile injectable tramadol solution for acute and post-op pain.' },
        { id: 'apt-pantodom', name: 'APT-PANTODOM', ingredient: 'Pantoprazole 40mg + Domperidone 30mg', category: 'prescription', categoryLabel: 'Prescription Medicines', pack: '1 x 10 SR Capsules', maker: 'APT Pharma', area: 'Gastroenterology', summary: 'Dual-action sustained release capsule for upper GI comfort.' },
        { id: 'afiten-5mg', name: 'AFITEN 5mg', ingredient: 'Amlodipine 5mg', category: 'prescription', categoryLabel: 'Prescription Medicines', pack: '30 Tablets', maker: 'Medochemie (EU-GMP)', area: 'Cardiovascular', summary: 'EU-GMP calcium channel blocker for daily hypertension management.' },
        { id: 'siranalen-75mg', name: 'SIRANALEN 75mg', ingredient: 'Pregabalin 75mg', category: 'prescription', categoryLabel: 'Prescription Medicines', pack: '75mg Capsules', maker: 'Medochemie (EU-GMP)', area: 'Neurology', summary: 'European GMP pregabalin capsules for neuropathic care.' },
        { id: 'celmantin-10mg', name: 'CELMANTIN 10mg', ingredient: 'Rosuvastatin 10mg', category: 'prescription', categoryLabel: 'Prescription Medicines', pack: '14 Film-Coated Tablets', maker: 'Medochemie (EU-GMP)', area: 'Lipid Management', summary: 'Film-coated rosuvastatin tablets for long-term lipid control.' },
        { id: 'almiral-100mg', name: 'ALMIRAL 100mg', ingredient: 'Diclofenac Sodium', category: 'prescription', categoryLabel: 'Prescription Medicines', pack: '10 Suppositories', maker: 'Medochemie (EU-GMP)', area: 'Anti-Inflammatory', summary: '100mg suppositories for rapid analgesic and anti-inflammatory relief.' },
        { id: 'ceejuicy', name: 'Ceejuicy', ingredient: 'Chewable Vitamin C', category: 'supplements', categoryLabel: 'Food Supplements', pack: '5 x 4 Chewable Tablets · Orange', maker: 'APT Consumer Health', area: 'Daily Immunity', summary: 'Great-tasting orange chewable Vitamin C for family immunity.' },
        { id: 'apt-mn', name: 'APT-M+N Effervescent', ingredient: 'Multivitamin & Minerals', category: 'supplements', categoryLabel: 'Food Supplements', pack: 'Effervescent Tube · Orange', maker: 'APT Consumer Health', area: 'Daily Nutrition', summary: 'Fast-dissolving orange multivitamin and mineral formula.' },
        { id: 'apt-m', name: 'APT-M Effervescent', ingredient: 'Multivitamin Formula', category: 'supplements', categoryLabel: 'Food Supplements', pack: 'Effervescent Tube · Orange', maker: 'APT Consumer Health', area: 'Daily Vitality', summary: 'Refreshing effervescent multivitamin blend for rapid absorption.' },
        { id: 'apt-c', name: 'APT-C Effervescent', ingredient: 'Vitamin C 180', category: 'supplements', categoryLabel: 'Food Supplements', pack: 'Effervescent Tube · Strawberry', maker: 'APT Consumer Health', area: 'Immune Defense', summary: 'Strawberry-flavored Vitamin C 180 effervescent antioxidant support.' },
        { id: 'apt-preg', name: 'APT-PREG', ingredient: 'Prenatal Multivitamin & Minerals', category: 'supplements', categoryLabel: 'Food Supplements', pack: '30 Capsules · Europe', maker: 'Nutrilo (Germany)', area: 'Prenatal Care', summary: 'European prenatal nutrition capsules supporting healthy pregnancy.' },
        { id: 'apt-livoforte', name: 'APT-LIVOFORTE', ingredient: 'Liver Tonic Formula', category: 'supplements', categoryLabel: 'Food Supplements', pack: '30 Capsules', maker: 'APT Consumer Health', area: 'Liver Health', summary: 'Targeted liver-support capsules for daily healthy living.' },
        { id: 'apt-menopause', name: 'APT-MENOPAUSE', ingredient: 'Women’s Vigor & Longevity', category: 'supplements', categoryLabel: 'Food Supplements', pack: '30 Capsules · Europe', maker: 'APT Consumer Health', area: 'Women’s Health', summary: 'European botanical and vitamin blend for women’s vitality.' }
      ];

      const NETWORK_LOCATIONS = [
        { name: 'Yangon', region: 'Lower Myanmar', type: 'head', label: 'Head Office' },
        { name: 'Mandalay', region: 'Upper Myanmar', type: 'branch', label: 'Branch Office' },
        { name: 'Nay Pyi Taw', region: 'Central Myanmar', type: 'branch', label: 'Branch Office' },
        { name: 'Lashio', region: 'Northern Shan', type: 'branch', label: 'Branch Office' },
        { name: 'Mawlamyine', region: 'Mon State', type: 'branch', label: 'Branch Office' },
        { name: 'Kachin State', region: 'Upper Myanmar', type: 'dealer', label: 'Dealer Hub' },
        { name: 'Sagaing Region', region: 'Upper Myanmar', type: 'dealer', label: 'Dealer Hub' },
        { name: 'Magway Region', region: 'Central Myanmar', type: 'dealer', label: 'Dealer Hub' },
        { name: 'Rakhine State', region: 'Western Myanmar', type: 'dealer', label: 'Dealer Hub' },
        { name: 'Southern Shan', region: 'Eastern Myanmar', type: 'dealer', label: 'Dealer Hub' },
        { name: 'Eastern Shan', region: 'Eastern Myanmar', type: 'dealer', label: 'Dealer Hub' },
        { name: 'Bago Region', region: 'Lower Myanmar', type: 'dealer', label: 'Dealer Hub' },
        { name: 'Ayeyarwady', region: 'Lower Myanmar', type: 'dealer', label: 'Dealer Hub' },
        { name: 'North Tanintharyi', region: 'Lower Myanmar', type: 'dealer', label: 'Dealer Hub' },
        { name: 'South Tanintharyi', region: 'Lower Myanmar', type: 'dealer', label: 'Dealer Hub' }
      ];

      const PAGES = [
        { id: 'home', title: 'Home', desc: 'Overview, metrics & divisions' },
        { id: 'about', title: 'About Us', desc: 'Leadership, values & milestones' },
        { id: 'products', title: 'Product Portfolio', desc: 'Browse all 18 verified products' },
        { id: 'why-us', title: 'Why APT', desc: '4 strategic growth advantages' },
        { id: 'partners', title: 'Partners & Network', desc: 'Global suppliers & K.T.Z hubs' },
        { id: 'contact', title: 'Contact Us', desc: 'Direct channels & inquiry form' }
      ];

      const state = {
        activeView: 'home',
        selectedCategory: 'all',
        searchQuery: '',
        networkFilter: 'all',
        shortlist: new Set(),
        activeModalProduct: null,
        lastPreparedText: ''
      };

      const VALID_VIEWS = ['home', 'about', 'products', 'why-us', 'partners', 'contact'];

      let toastTimer = null;
      function showToast(msg) {
        const toastEl = document.getElementById('toast');
        const msgEl = document.getElementById('toast-message');
        if (!toastEl || !msgEl) return;
        msgEl.textContent = msg;
        toastEl.classList.remove('hidden');
        toastEl.classList.add('flex');
        if (toastTimer) clearTimeout(toastTimer);
        toastTimer = setTimeout(() => {
          toastEl.classList.add('hidden');
          toastEl.classList.remove('flex');
        }, 2800);
      }

      function navigateTo(viewName, options) {
        const target = VALID_VIEWS.includes(viewName) ? viewName : 'home';
        state.activeView = target;

        document.querySelectorAll('.view-panel').forEach((panel) => {
          panel.classList.toggle('active', panel.id === 'view-' + target);
        });
        document.querySelectorAll('.nav-link-btn').forEach((btn) => {
          btn.classList.toggle('active', btn.dataset.nav === target);
        });

        const mobileMenu = document.getElementById('mobile-menu');
        const mobileBtn = document.getElementById('mobile-menu-btn');
        if (mobileMenu && !mobileMenu.classList.contains('hidden')) {
          mobileMenu.classList.add('hidden');
          if (mobileBtn) mobileBtn.setAttribute('aria-expanded', 'false');
        }

        if (!options || !options.skipHash) {
          try { window.history.replaceState(null, '', '#' + target); } catch (e) {}
        }
        window.scrollTo({ top: 0, behavior: 'smooth' });
        setupScrollReveal();
      }

      let revealObserver = null;
      function setupScrollReveal() {
        const activePanel = document.querySelector('.view-panel.active');
        if (!activePanel) return;
        const els = activePanel.querySelectorAll('.reveal');
        if (!els.length) return;

        if (revealObserver) revealObserver.disconnect();

        if (!('IntersectionObserver' in window)) {
          els.forEach((el) => el.classList.add('is-visible'));
          return;
        }

        revealObserver = new IntersectionObserver((entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              entry.target.classList.add('is-visible');
              revealObserver.unobserve(entry.target);
            }
          });
        }, { threshold: 0.12, rootMargin: '0px 0px -36px 0px' });

        els.forEach((el) => {
          el.classList.remove('is-visible');
          const rect = el.getBoundingClientRect();
          if (rect.top < window.innerHeight * 0.92) {
            requestAnimationFrame(() => el.classList.add('is-visible'));
          } else {
            revealObserver.observe(el);
          }
        });
      }

      function syncShortlistUI() {
        const count = state.shortlist.size;
        const headerBtn = document.getElementById('header-shortlist-btn');
        const headerCount = document.getElementById('header-shortlist-count');
        const bar = document.getElementById('shortlist-bar');
        const barCount = document.getElementById('shortlist-bar-count');

        if (headerBtn && headerCount) {
          headerCount.textContent = String(count);
          headerBtn.classList.toggle('hidden', count === 0);
          headerBtn.classList.toggle('inline-flex', count > 0);
        }
        if (bar && barCount) {
          barCount.textContent = String(count);
          bar.classList.toggle('hidden', count === 0);
          bar.classList.toggle('flex', count > 0);
        }
        if (state.activeModalProduct) {
          const isSaved = state.shortlist.has(state.activeModalProduct.id);
          const lbl = document.getElementById('modal-shortlist-label');
          if (lbl) lbl.textContent = isSaved ? 'Shortlisted' : 'Add to Shortlist';
        }
      }

      function toggleShortlist(productId) {
        const prod = PRODUCTS.find((p) => p.id === productId);
        if (!prod) return;
        if (state.shortlist.has(productId)) {
          state.shortlist.delete(productId);
          showToast('Removed ' + prod.name + ' from shortlist');
        } else {
          state.shortlist.add(productId);
          showToast('Added ' + prod.name + ' to inquiry shortlist');
        }
        syncShortlistUI();
        renderProducts();
      }

      function sendShortlistToContact() {
        const names = Array.from(state.shortlist)
          .map((id) => PRODUCTS.find((p) => p.id === id))
          .filter(Boolean)
          .map((p) => p.name);
        if (names.length === 0) return;
        const prodInput = document.getElementById('c-product');
        const topicSelect = document.getElementById('c-topic');
        if (prodInput) prodInput.value = names.join(', ');
        if (topicSelect) topicSelect.value = 'Product Portfolio Inquiry';
        navigateTo('contact');
        showToast(names.length + ' shortlisted product(s) added to form');
      }

      function renderProducts() {
        const grid = document.getElementById('products-grid');
        const empty = document.getElementById('products-empty');
        const countLabel = document.getElementById('product-count-label');
        const resetBtn = document.getElementById('reset-filters-btn');
        if (!grid) return;

        const q = state.searchQuery.trim().toLowerCase();
        const filtered = PRODUCTS.filter((p) => {
          const matchCat = state.selectedCategory === 'all' || p.category === state.selectedCategory;
          const hay = (p.name + ' ' + p.ingredient + ' ' + p.maker + ' ' + p.area + ' ' + p.categoryLabel).toLowerCase();
          return matchCat && (!q || hay.includes(q));
        });

        document.querySelectorAll('.cat-tab').forEach((tab) => {
          const active = tab.dataset.category === state.selectedCategory;
          tab.className = active
            ? 'cat-tab px-3.5 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-colors bg-gold-500 text-white'
            : 'cat-tab px-3.5 py-2 rounded-lg text-xs sm:text-sm font-medium transition-colors bg-slate-100 text-slate-700 hover:bg-gold-50';
        });

        const isFiltered = state.selectedCategory !== 'all' || q.length > 0;
        if (resetBtn) resetBtn.classList.toggle('hidden', !isFiltered);
        if (countLabel) countLabel.textContent = 'Showing ' + filtered.length + ' of ' + PRODUCTS.length + ' products';

        if (filtered.length === 0) {
          grid.innerHTML = '';
          if (empty) empty.classList.remove('hidden');
          return;
        }
        if (empty) empty.classList.add('hidden');

        const badgeMap = {
          antibiotics: 'bg-clinical-50 text-clinical-700 border-clinical-100',
          prescription: 'bg-slate-100 text-navy-900 border-slate-200',
          supplements: 'bg-gold-50 text-gold-700 border-gold-200'
        };

        grid.innerHTML = filtered.map((p) => {
          const badgeClass = badgeMap[p.category] || 'bg-slate-100 text-slate-700';
          const saved = state.shortlist.has(p.id);
          return `
            <article class="bg-white rounded-2xl border ${saved ? 'border-gold-400 ring-1 ring-gold-200' : 'border-slate-200'} p-5 smart-card flex flex-col justify-between">
              <div>
                <div class="flex items-center justify-between gap-2 mb-2.5">
                  <span class="inline-flex items-center px-2 py-0.5 rounded border text-[10px] font-bold uppercase tracking-wide ${badgeClass}">${p.categoryLabel}</span>
                  <span class="text-[11px] font-medium text-slate-500 truncate">${p.maker}</span>
                </div>
                <h3 class="text-base font-bold text-navy-900">${p.name}</h3>
                <p class="text-xs font-semibold text-gold-700 mt-0.5">${p.ingredient}</p>
                <p class="text-xs text-slate-600 mt-2.5 leading-relaxed">${p.summary}</p>
              </div>
              <div class="mt-4 pt-3.5 border-t border-slate-100 flex items-center justify-between gap-2">
                <button type="button" data-toggle-shortlist="${p.id}" class="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors ${saved ? 'bg-gold-500 text-white' : 'bg-slate-100 text-slate-700 hover:bg-gold-50 hover:text-gold-700'}">
                  <i data-lucide="${saved ? 'check' : 'plus'}" class="w-3 h-3"></i>
                  <span>${saved ? 'Shortlisted' : 'Shortlist'}</span>
                </button>
                <button type="button" data-open-product="${p.id}" class="inline-flex items-center gap-1 text-xs font-semibold text-gold-700 hover:text-gold-600">
                  <span>Specs</span>
                  <i data-lucide="arrow-up-right" class="w-3.5 h-3.5"></i>
                </button>
              </div>
            </article>
          `;
        }).join('');

        if (window.lucide) window.lucide.createIcons();
      }

      function openProductModal(productId) {
        const product = PRODUCTS.find((p) => p.id === productId);
        const modal = document.getElementById('product-modal');
        if (!product || !modal) return;
        state.activeModalProduct = product;
        document.getElementById('modal-category-badge').textContent = product.categoryLabel;
        document.getElementById('modal-product-name').textContent = product.name;
        document.getElementById('modal-ingredient').textContent = product.ingredient;
        document.getElementById('modal-summary').textContent = product.summary;
        document.getElementById('modal-pack').textContent = product.pack;
        document.getElementById('modal-maker').textContent = product.maker;
        document.getElementById('modal-area').textContent = product.area;
        syncShortlistUI();
        modal.classList.remove('hidden');
        modal.classList.add('flex');
      }

      function closeProductModal() {
        const modal = document.getElementById('product-modal');
        if (!modal) return;
        modal.classList.add('hidden');
        modal.classList.remove('flex');
        state.activeModalProduct = null;
      }

      // Smart Quick Search Command Palette
      function openCmdModal() {
        const modal = document.getElementById('cmd-modal');
        const input = document.getElementById('cmd-input');
        if (!modal || !input) return;
        modal.classList.remove('hidden');
        modal.classList.add('flex');
        input.value = '';
        renderCmdResults('');
        setTimeout(() => input.focus(), 40);
      }

      function closeCmdModal() {
        const modal = document.getElementById('cmd-modal');
        if (!modal) return;
        modal.classList.add('hidden');
        modal.classList.remove('flex');
      }

      function renderCmdResults(query) {
        const container = document.getElementById('cmd-results');
        if (!container) return;
        const q = query.trim().toLowerCase();

        const matchedPages = PAGES.filter((pg) => !q || (pg.title + ' ' + pg.desc).toLowerCase().includes(q)).slice(0, 4);
        const matchedProducts = PRODUCTS.filter((p) => !q || (p.name + ' ' + p.ingredient + ' ' + p.maker).toLowerCase().includes(q)).slice(0, 6);
        const matchedHubs = q ? NETWORK_LOCATIONS.filter((l) => (l.name + ' ' + l.region).toLowerCase().includes(q)).slice(0, 3) : [];

        let html = '';
        if (matchedProducts.length) {
          html += '<div class="px-2.5 pt-2 pb-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">Products</div>';
          html += matchedProducts.map((p) => `
            <button type="button" data-cmd-product="${p.id}" class="w-full text-left px-3 py-2 rounded-lg hover:bg-gold-50 flex items-center justify-between gap-2 transition-colors">
              <div>
                <div class="text-sm font-semibold text-navy-900">${p.name}</div>
                <div class="text-xs text-slate-500">${p.ingredient} · ${p.maker}</div>
              </div>
              <span class="text-[10px] font-semibold text-gold-700 bg-gold-50 px-2 py-0.5 rounded">${p.categoryLabel}</span>
            </button>
          `).join('');
        }
        if (matchedPages.length) {
          html += '<div class="px-2.5 pt-2 pb-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">Pages</div>';
          html += matchedPages.map((pg) => `
            <button type="button" data-cmd-page="${pg.id}" class="w-full text-left px-3 py-2 rounded-lg hover:bg-gold-50 flex items-center justify-between gap-2 transition-colors">
              <span class="text-sm font-semibold text-navy-900">${pg.title}</span>
              <span class="text-xs text-slate-500">${pg.desc}</span>
            </button>
          `).join('');
        }
        if (matchedHubs.length) {
          html += '<div class="px-2.5 pt-2 pb-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">Distribution Hubs</div>';
          html += matchedHubs.map((h) => `
            <button type="button" data-cmd-page="partners" class="w-full text-left px-3 py-2 rounded-lg hover:bg-gold-50 flex items-center justify-between gap-2 transition-colors">
              <span class="text-sm font-semibold text-navy-900">${h.name}</span>
              <span class="text-xs text-slate-500">${h.label} · ${h.region}</span>
            </button>
          `).join('');
        }
        if (!html) {
          html = '<div class="p-6 text-center text-xs text-slate-500">No results for "' + query.replace(/</g, '&lt;') + '"</div>';
        }
        container.innerHTML = html;
      }

      function renderNetwork() {
        const grid = document.getElementById('network-grid');
        if (!grid) return;

        document.querySelectorAll('.net-filter-btn').forEach((btn) => {
          const active = btn.dataset.netFilter === state.networkFilter;
          btn.className = active
            ? 'net-filter-btn px-3 py-1.5 rounded-lg text-xs font-semibold bg-gold-500 text-white transition-colors'
            : 'net-filter-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-100 text-slate-700 hover:bg-gold-50 transition-colors';
        });

        const items = NETWORK_LOCATIONS.filter((loc) => state.networkFilter === 'all' || loc.type === state.networkFilter);
        const dotColors = { head: 'bg-gold-500', branch: 'bg-clinical-600', dealer: 'bg-slate-400' };

        grid.innerHTML = items.map((loc) => `
          <div class="p-3.5 rounded-xl border border-slate-200 bg-ivory/40 flex items-center justify-between gap-3">
            <div class="flex items-center gap-2.5">
              <span class="w-2 h-2 rounded-full shrink-0 ${dotColors[loc.type] || 'bg-slate-400'}"></span>
              <div>
                <div class="text-sm font-bold text-navy-900">${loc.name}</div>
                <div class="text-[11px] text-slate-500">${loc.region}</div>
              </div>
            </div>
            <span class="text-[10px] font-semibold px-2 py-0.5 rounded bg-white border border-slate-200 text-slate-600 shrink-0">${loc.label}</span>
          </div>
        `).join('');
      }

      function copyText(text) {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(text).then(() => showToast('Inquiry copied to clipboard')).catch(() => fallbackCopy(text));
        } else {
          fallbackCopy(text);
        }
      }

      function fallbackCopy(text) {
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        try {
          document.execCommand('copy');
          showToast('Inquiry copied to clipboard');
        } catch (e) {
          showToast('Please copy the text manually');
        }
        document.body.removeChild(ta);
      }

      function init() {
        const yearEl = document.getElementById('footer-year');
        if (yearEl) yearEl.textContent = String(new Date().getFullYear());

        // Scroll progress hairline
        const progressEl = document.getElementById('scroll-progress');
        window.addEventListener('scroll', () => {
          if (!progressEl) return;
          const docH = document.documentElement.scrollHeight - window.innerHeight;
          const pct = docH > 0 ? Math.min(100, Math.max(0, (window.scrollY / docH) * 100)) : 0;
          progressEl.style.width = pct + '%';
        }, { passive: true });

        document.querySelectorAll('[data-nav]').forEach((el) => {
          el.addEventListener('click', () => navigateTo(el.dataset.nav));
        });

        document.querySelectorAll('[data-goto-category]').forEach((btn) => {
          btn.addEventListener('click', () => {
            state.selectedCategory = btn.dataset.gotoCategory;
            state.searchQuery = '';
            const searchInput = document.getElementById('product-search-input');
            if (searchInput) searchInput.value = '';
            renderProducts();
            navigateTo('products');
          });
        });

        const mobileBtn = document.getElementById('mobile-menu-btn');
        const mobileMenu = document.getElementById('mobile-menu');
        if (mobileBtn && mobileMenu) {
          mobileBtn.addEventListener('click', () => {
            const isHidden = mobileMenu.classList.toggle('hidden');
            mobileBtn.setAttribute('aria-expanded', String(!isHidden));
          });
        }

        // Quick Search Command Palette events
        const openCmdBtn = document.getElementById('open-cmd-btn');
        const closeCmdBtn = document.getElementById('close-cmd-btn');
        const cmdModal = document.getElementById('cmd-modal');
        const cmdInput = document.getElementById('cmd-input');
        const cmdResults = document.getElementById('cmd-results');

        if (openCmdBtn) openCmdBtn.addEventListener('click', openCmdModal);
        if (closeCmdBtn) closeCmdBtn.addEventListener('click', closeCmdModal);
        if (cmdModal) {
          cmdModal.addEventListener('click', (e) => { if (e.target === cmdModal) closeCmdModal(); });
        }
        if (cmdInput) {
          cmdInput.addEventListener('input', (e) => renderCmdResults(e.target.value));
        }
        if (cmdResults) {
          cmdResults.addEventListener('click', (e) => {
            const prodBtn = e.target.closest('[data-cmd-product]');
            const pageBtn = e.target.closest('[data-cmd-page]');
            if (prodBtn) {
              closeCmdModal();
              navigateTo('products');
              openProductModal(prodBtn.dataset.cmdProduct);
            } else if (pageBtn) {
              closeCmdModal();
              navigateTo(pageBtn.dataset.cmdPage);
            }
          });
        }

        // Keyboard shortcuts (Ctrl+K / Cmd+K & Escape)
        document.addEventListener('keydown', (e) => {
          if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
            e.preventDefault();
            openCmdModal();
          } else if (e.key === 'Escape') {
            closeCmdModal();
            if (state.activeModalProduct) closeProductModal();
          }
        });

        // Shortlist buttons
        const headerShortlistBtn = document.getElementById('header-shortlist-btn');
        const inquireShortlistBtn = document.getElementById('inquire-shortlist-btn');
        const clearShortlistBtn = document.getElementById('clear-shortlist-btn');
        const modalShortlistBtn = document.getElementById('modal-shortlist-btn');

        if (headerShortlistBtn) headerShortlistBtn.addEventListener('click', sendShortlistToContact);
        if (inquireShortlistBtn) inquireShortlistBtn.addEventListener('click', sendShortlistToContact);
        if (clearShortlistBtn) {
          clearShortlistBtn.addEventListener('click', () => {
            state.shortlist.clear();
            syncShortlistUI();
            renderProducts();
            showToast('Shortlist cleared');
          });
        }
        if (modalShortlistBtn) {
          modalShortlistBtn.addEventListener('click', () => {
            if (state.activeModalProduct) toggleShortlist(state.activeModalProduct.id);
          });
        }

        // Product filters & search
        document.querySelectorAll('.cat-tab').forEach((tab) => {
          tab.addEventListener('click', () => {
            state.selectedCategory = tab.dataset.category;
            renderProducts();
          });
        });

        const searchInput = document.getElementById('product-search-input');
        if (searchInput) {
          searchInput.addEventListener('input', (e) => {
            state.searchQuery = e.target.value;
            renderProducts();
          });
        }

        function resetProductFilters() {
          state.selectedCategory = 'all';
          state.searchQuery = '';
          if (searchInput) searchInput.value = '';
          renderProducts();
        }
        const resetBtn = document.getElementById('reset-filters-btn');
        const emptyResetBtn = document.getElementById('empty-reset-btn');
        if (resetBtn) resetBtn.addEventListener('click', resetProductFilters);
        if (emptyResetBtn) emptyResetBtn.addEventListener('click', resetProductFilters);

        const productsGrid = document.getElementById('products-grid');
        if (productsGrid) {
          productsGrid.addEventListener('click', (e) => {
            const slBtn = e.target.closest('[data-toggle-shortlist]');
            if (slBtn) { toggleShortlist(slBtn.dataset.toggleShortlist); return; }
            const openBtn = e.target.closest('[data-open-product]');
            if (openBtn) openProductModal(openBtn.dataset.openProduct);
          });
        }

        // Product Modal events
        const closeBtn = document.getElementById('close-modal-btn');
        const secCloseBtn = document.getElementById('modal-secondary-close');
        const modalBackdrop = document.getElementById('product-modal');
        const modalInquireBtn = document.getElementById('modal-inquire-btn');

        if (closeBtn) closeBtn.addEventListener('click', closeProductModal);
        if (secCloseBtn) secCloseBtn.addEventListener('click', closeProductModal);
        if (modalBackdrop) {
          modalBackdrop.addEventListener('click', (e) => { if (e.target === modalBackdrop) closeProductModal(); });
        }
        if (modalInquireBtn) {
          modalInquireBtn.addEventListener('click', () => {
            const prod = state.activeModalProduct;
            closeProductModal();
            if (prod) {
              const prodInput = document.getElementById('c-product');
              const topicSelect = document.getElementById('c-topic');
              if (prodInput) prodInput.value = prod.name + ' (' + prod.ingredient + ')';
              if (topicSelect) topicSelect.value = 'Product Portfolio Inquiry';
            }
            navigateTo('contact');
            showToast('Product added to inquiry form');
          });
        }

        // Network filter
        document.querySelectorAll('.net-filter-btn').forEach((btn) => {
          btn.addEventListener('click', () => {
            state.networkFilter = btn.dataset.netFilter;
            renderNetwork();
          });
        });

        // Contact form
        const form = document.getElementById('corporate-contact-form');
        const errorBox = document.getElementById('form-error');
        const resultBox = document.getElementById('inquiry-result');
        const summaryText = document.getElementById('inquiry-summary-text');
        const mailtoLink = document.getElementById('mailto-launch-link');
        const copyBtn = document.getElementById('copy-inquiry-btn');
        const clearBtn = document.getElementById('clear-form-btn');

        if (form) {
          form.addEventListener('submit', (e) => {
            e.preventDefault();
            const name = document.getElementById('c-name').value.trim();
            const org = document.getElementById('c-org').value.trim();
            const email = document.getElementById('c-email').value.trim();
            const phone = document.getElementById('c-phone').value.trim();
            const topic = document.getElementById('c-topic').value;
            const product = document.getElementById('c-product').value.trim();
            const message = document.getElementById('c-message').value.trim();

            if (!name || !org || !email || !message) {
              errorBox.textContent = 'Please complete all required fields.';
              errorBox.classList.remove('hidden');
              resultBox.classList.add('hidden');
              return;
            }
            if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
              errorBox.textContent = 'Please enter a valid work email.';
              errorBox.classList.remove('hidden');
              resultBox.classList.add('hidden');
              return;
            }

            errorBox.classList.add('hidden');
            const subject = '[APT Inquiry] ' + topic + (product ? ' — ' + product : '') + ' (' + org + ')';
            const bodyLines = [
              'Name: ' + name,
              'Organization: ' + org,
              'Email: ' + email,
              phone ? 'Phone: ' + phone : null,
              'Topic: ' + topic,
              product ? 'Products: ' + product : null,
              '',
              message
            ].filter((line) => line !== null).join('\n');

            state.lastPreparedText = 'To: info@aungpaingtun.com\nSubject: ' + subject + '\n\n' + bodyLines;
            summaryText.textContent = state.lastPreparedText;
            mailtoLink.href = 'mailto:info@aungpaingtun.com?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(bodyLines);
            resultBox.classList.remove('hidden');
            showToast('Inquiry ready to send or copy');
          });
        }

        if (copyBtn) {
          copyBtn.addEventListener('click', () => { if (state.lastPreparedText) copyText(state.lastPreparedText); });
        }
        if (clearBtn && form) {
          clearBtn.addEventListener('click', () => {
            form.reset();
            errorBox.classList.add('hidden');
            resultBox.classList.add('hidden');
            state.lastPreparedText = '';
          });
        }

        const initialHash = (window.location.hash || '').replace('#', '');
        if (VALID_VIEWS.includes(initialHash)) navigateTo(initialHash, { skipHash: true });

        renderProducts();
        renderNetwork();
        syncShortlistUI();
        setupScrollReveal();
        if (window.lucide) window.lucide.createIcons();
      }

      document.addEventListener('DOMContentLoaded', init);
    })();
