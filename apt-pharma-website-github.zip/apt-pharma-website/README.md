# Aung Paing Tun Co., Ltd. (APT Pharma) — Corporate Website

Official corporate website source code for **Aung Paing Tun Co., Ltd. (APT Pharma)**, ready for GitHub and GitHub Pages deployment.

## Folder & Path Structure

```text
apt-pharma-website/
├── index.html                        # Main website entry point
├── css/
│   └── style.css                     # Custom theme, hover-lift & scroll-reveal transitions
├── js/
│   └── app.js                        # SPA navigation, Quick Search (Ctrl+K), Shortlist, Filters & Inquiry Form
├── assets/
│   └── images/
│       ├── logo.png                  # Official APT logo
│       ├── office-building.jpg       # Hero corporate visual
│       ├── office-team.jpg           # Corporate team photo
│       ├── warehouse.jpg             # Distribution logistics visual
│       ├── supplements.jpg           # Consumer wellness visual
│       ├── poland.png                # EU origin flag
│       └── suppliers/
│           ├── medo.png              # Medochemie logo
│           ├── nutrilo.png           # Nutrilo logo
│           ├── zp.png                # Zeiss Pharma logo
│           ├── pl.jpg                # European partner logo
│           ├── samrudh.png           # Samrudh Pharmaceuticals logo
│           └── scitech.png           # SciTech Specialities logo
├── .gitignore
└── README.md
```

## Deploy to GitHub Pages

1. Unzip `apt-pharma-website-github.zip` and open the `apt-pharma-website/` folder.
2. Initialize and push to your GitHub repository:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: APT Pharma corporate website"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<your-repo>.git
   git push -u origin main
   ```
3. In GitHub, go to **Settings → Pages**, select **Deploy from a branch**, choose `main` and `/ (root)`, and click **Save**.
